@php
    use App\Repositories\Storefront\CatalogRepository;
    use Illuminate\Support\Facades\Cache;

    $store = $store ?? (app()->bound('currentStore') ? app('currentStore') : null);
    $locale = $locale ?? app()->getLocale();
    $storeName = $store->name ?? 'CIAK';
    $storeLogo = $store?->logo_url ? media_url($store->logo_url) : null;
    $contextParams = $contextParams ?? [];
    $companyName = $store->company_name ?? $store->ragione_sociale ?? $storeName;
    $companyEmail = $store->email ?? $store->company_email ?? null;
    $companyPhone = $store->phone ?? $store->company_phone ?? null;

    $footerNavigation = collect();
    if ($store) {
        try {
            $footerNavigation = collect(Cache::remember(
                'ciak-footer-navigation:' . $store->id . ':' . $locale,
                now()->addMinutes(30),
                fn () => app(CatalogRepository::class)->getNavigationTree($store, $locale)->all()
            ));
        } catch (Throwable) {
            $footerNavigation = collect();
        }
    }
@endphp

<footer class="ciak-footer">
    <div class="ciak-footer-main">
        <div class="ciak-footer-brand">
            <a href="{{ route('storefront.home', $contextParams) }}" aria-label="{{ $storeName }}">
                @if($storeLogo)
                    <img src="{{ $storeLogo }}" alt="{{ $storeName }}" loading="lazy" decoding="async">
                @else
                    <span>CIAK</span>
                @endif
            </a>
            <small>{{ $companyName }}</small>
        </div>

        <nav class="ciak-footer-nav" aria-label="{{ __('Shop') }}">
            <strong>{{ __('Shop') }}</strong>
            <a href="{{ route('storefront.catalog.index', $contextParams) }}">{{ __('Tutti i prodotti') }}</a>
            @foreach($footerNavigation->filter(fn ($item) => !empty($item['slug']))->take(5) as $category)
                <a href="{{ route('storefront.category.show', array_merge(['slug' => $category['slug']], $contextParams)) }}">
                    {{ $category['label'] ?? $category['code'] }}
                </a>
            @endforeach
        </nav>

        <nav class="ciak-footer-nav" aria-label="{{ __('Account') }}">
            <strong>{{ __('Account') }}</strong>
            @auth('customer')
                <a href="{{ route('storefront.account.index', $contextParams) }}">{{ __('Il mio account') }}</a>
            @else
                <a href="{{ route('storefront.login', $contextParams) }}">{{ __('Accedi') }}</a>
            @endauth
            @if(Route::has('storefront.wishlist.index'))
                <a href="{{ route('storefront.wishlist.index', $contextParams) }}">{{ __('Preferiti') }}</a>
            @endif
            <a href="{{ route('storefront.cart.index', $contextParams) }}">{{ __('Carrello') }}</a>
        </nav>

        <div class="ciak-footer-contact">
            <strong>{{ __('Contatti') }}</strong>
            @if($companyEmail)<a href="mailto:{{ $companyEmail }}">{{ $companyEmail }}</a>@endif
            @if($companyPhone)<a href="tel:{{ preg_replace('/\s+/', '', (string) $companyPhone) }}">{{ $companyPhone }}</a>@endif
        </div>
    </div>

    <div class="ciak-footer-bottom">
        <span>© {{ date('Y') }} {{ $storeName }}</span>
        <span>{{ __('Tutti i diritti riservati') }}</span>
    </div>
</footer>
